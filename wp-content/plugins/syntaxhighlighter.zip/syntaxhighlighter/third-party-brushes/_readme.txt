Hi.

If you're trying to add other brushes to this plugin, please don't store
them in this folder as they'll be deleted when you upgrade this plugin.

Instead check out this page on my blog:

http://www.viper007bond.com/wordpress-plugins/syntaxhighlighter/adding-a-new-brush-language/

It explains how to hook into my plugin to add additional brushes.
If you follow those instructions, you can store your brush file anywhere
you want.

-Viper